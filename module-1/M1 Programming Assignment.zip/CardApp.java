//Kristopher Kuenning
//08/17/2025
//CSD-420
//Module 1 Programming Assignment

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CardApp extends Application {

    private static final int NUM_CARDS = 52;
    private static final int DRAW_COUNT = 4;
    private static final boolean LOAD_FROM_FILESYSTEM = true;

    private final HBox cardRow = new HBox(12);

    @Override
    public void start(Stage stage) {
        cardRow.setAlignment(Pos.CENTER);

        //Below the cards, there will be a refresh button that will then display four different cards.
        Button refresh = new Button("Refresh");
        refresh.setDefaultButton(true);

        // Lambda expression
        refresh.setOnAction(e -> showRandomCards());

        VBox bottom = new VBox(10, refresh);
        bottom.setAlignment(Pos.CENTER);
        bottom.setPadding(new Insets(12));

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(16));
        root.setCenter(cardRow);
        root.setBottom(bottom);

        Scene scene = new Scene(root, 760, 340);
        stage.setTitle("Random 4-Card Draw");
        stage.setScene(scene);
        stage.show();

        showRandomCards();
    }

    private void showRandomCards() {
        cardRow.getChildren().clear();

        // Using these cards, randomly select four cards for display.
        List<Integer> draw = IntStream.rangeClosed(1, NUM_CARDS)
                .boxed()
                .collect(Collectors.toList());
        Collections.shuffle(draw);
        draw = draw.subList(0, DRAW_COUNT);

        for (int cardNum : draw) {
            Image img = loadCardImage(cardNum);
            ImageView iv = new ImageView(img);
            iv.setPreserveRatio(true);
            iv.setFitHeight(240);
            cardRow.getChildren().add(iv);
        }
    }

    private Image loadCardImage(int cardNumber) {
        String fileName = cardNumber + ".png";

        if (LOAD_FROM_FILESYSTEM) {
            String uri = "file:cards/" + fileName;
            return safeImage(uri);
        } else {
            URL url = getClass().getResource("/cards/" + fileName);
            if (url == null) {
                String uri = "file:cards/" + fileName;
                return safeImage(uri);
            }
            return new Image(url.toExternalForm(), true);
        }
    }

    private Image safeImage(String uri) {
        return new Image(uri, true);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
